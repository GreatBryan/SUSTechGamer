from pymouse import PyMouse
from pykeyboard import PyKeyboard
from PIL import Image
from threading import Thread
from detect import detect
from ocr import ocr
import pyautogui
import numpy as np
import cv2
import time


def run(img_path):
    ocr(img_path)


if __name__ == '__main__':
    start = time.time()

    # 获取屏幕截图
    screenshot = pyautogui.screenshot(region=[0, 0, 1920, 1080])  # x,y,w,h
    screenshot.save('pic/screenshot.jpg')

    # 取屏幕截图分成多个部分
    img = cv2.imread('pic/pic.png')
    # 飞机当前数据
    img_data = img[0:350, 0:250]
    cv2.imwrite('pic/region_data.jpg', img_data)
    # 飞机损伤情况
    img_damage = img[850:1050, 0:250]
    cv2.imwrite('pic/region_damage.jpg', img_damage)
    # 地图（雷达）数据
    img_map = img[0:250, 1660:1910]
    cv2.imwrite('pic/region_map.jpg', img_map)

    end = time.time()
    print('seconds:', round(end - start, 6))
    start = time.time()

    # 过滤截图只剩红色（用白色显示）
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    low_hsv = np.array([0, 43, 46])
    high_hsv = np.array([10, 255, 255])
    mask_red = cv2.inRange(hsv, lowerb=low_hsv, upperb=high_hsv)
    cv2.imwrite('pic/screen_red.jpg', mask_red)

    # 过滤截图只剩蓝色（用白色显示）
    sv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    low_hsv = np.array([112, 43, 46])
    high_hsv = np.array([124, 255, 255])
    mask_blue = cv2.inRange(hsv, lowerb=low_hsv, upperb=high_hsv)
    cv2.imwrite('pic/screen_blue.jpg', mask_blue)

    img = cv2.imread('pic/screen_red.jpg')
    region = detect(img)
    end = time.time()
    print('seconds:', round(end - start, 6))
    start = time.time()

    threads = []
    cnt = 1
    for r in region:
        tmp = img[r[2][1]:r[0][1], r[2][0]:r[0][0]]
        img_path = 'pic/' + str(cnt) + 'tmp.jpg'
        ocr(img_path)
        cv2.imwrite(img_path, tmp)
        # t = Thread(target=run, args=(img_path,))
        # t.setDaemon(True)
        # threads.append(t)
        # cnt += 1
        # print(r)

    # t = Thread(target=run, args=('pic/region_data.jpg',))
    # t.setDaemon(True)
    # threads.append(t)
    #
    # for t in threads:
    #     t.start()
    #
    # for t in threads:
    #     t.join()

    # OCR('pic/region_data.jpg')
    end = time.time()
    print('seconds:', round(end - start, 6))
