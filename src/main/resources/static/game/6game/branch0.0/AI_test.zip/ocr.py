import requests
import base64
import time


# 24.369cf4769f1669e9876087a7119b9da8.2592000.1608559782.282335-23021910
def ocr(img_path):
    start = time.time()

    '''
    通用文字识别
    '''
    request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic"
    # 二进制方式打开图片文件
    f = open(img_path, 'rb')
    img = base64.b64encode(f.read())
    params = {"image": img}
    access_token = '24.369cf4769f1669e9876087a7119b9da8.2592000.1608559782.282335-23021910'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    if response:
        print(response.json())

    end = time.time()
    # print('seconds', round(end - start, 6))

    # host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id
    # =0xH7AGhMlrR1CXgPdGGHWgcs&client_secret=ExDQjqRfht6R8sMRdhBk67FYRENFoVg2'
    # response = requests.get(host)
    # if response:
    #     print(response.json()['words_result'])


if __name__ == '__main__':
    img_path = 'pic/region_data.jpg'
    ocr(img_path)
